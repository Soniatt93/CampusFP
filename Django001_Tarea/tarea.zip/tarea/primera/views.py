from django.shortcuts import render
from primera.models import Project

def project_index(request):
    primera = Project.objects.all()
    context = {
        'primera': primera
    }
    return render(request, 'project_index.html', context)

def project_detail(request):
    primera = Project.objects.all()
    context = {
        'primera': primera
    }
    return render(request, 'project_detail.html', context)