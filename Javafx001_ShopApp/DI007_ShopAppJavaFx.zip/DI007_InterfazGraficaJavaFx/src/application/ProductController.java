package application;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;

public class ProductController {

    private Main main;
    
	@FXML
    private TableView<Product> productTable;
    @FXML
    private TableColumn<Product, String> descripcionColumn;
    @FXML
    private TableColumn<Product, Integer> stockColumn;
    
	@FXML
    private Label  txtDescripcion;

    @FXML
    private Label  txtPrecio;

    @FXML
    private Label  txtStock;

    @FXML
    private Label  txtFecha;
    
   
    public ProductController() {
    }

    /**
     * Initializes the controller class. This method is automatically called
     * after the fxml file has been loaded.
     */
    @FXML
    private void initialize() {
        // Initialize the person table with the two columns.
    	descripcionColumn.setCellValueFactory(
                cellData -> cellData.getValue().descripcionProperty());
    	stockColumn.setCellValueFactory(
                cellData -> cellData.getValue().stockProperty().asObject());

        // Clear person details.
        showProductDetails(null);

        // Listen for selection changes and show the person details when changed.
        productTable.getSelectionModel().selectedItemProperty().addListener(
                (observable, oldValue, newValue) -> showProductDetails(newValue));
    }

    
    @FXML
    private void handleNewProduct() {
    	Product tempProduct = new Product();
        boolean okClicked = main.showProductEditDialog(tempProduct);
        if(okClicked) {
        	main.getProductData().add(tempProduct);
        }
    }

    @FXML
    private void handleEditProduct() {
    	Product selectedProduct = productTable.getSelectionModel().getSelectedItem();
    	
        if(selectedProduct != null) {
            boolean okClicked = main.showProductEditDialog(selectedProduct);
            if (okClicked) {
                showProductDetails(selectedProduct);
            }
       }else {
                // Nothing selected.
                Alert alert = new Alert(AlertType.WARNING);
                alert.initOwner(main.getPrimaryStage());
                alert.setTitle("No Selection");
                alert.setHeaderText("No Product Selected");
                alert.setContentText("Please select a product in the table.");
                
                alert.showAndWait();
        }
    }
    
    @FXML
    private void handleDeleteProduct() {
        int selectedIndex = productTable.getSelectionModel().getSelectedIndex();
        if(selectedIndex>=0) {
        	productTable.getItems().remove(selectedIndex);
        }else {
            // Nothing selected.
            Alert alert = new Alert(AlertType.WARNING);
            alert.initOwner(main.getPrimaryStage());
            alert.setTitle("No Selection");
            alert.setHeaderText("No Product Selected");
            alert.setContentText("Please select a product in the table.");
            
            alert.showAndWait();
        }
    }
    
    
    private void showProductDetails(Product product) {
        if (product != null) {
            // Fill the labels with info from the person object.
            txtDescripcion.setText(product.getDescripcion());
            txtStock.setText(Integer.toString(product.getStock()));
            txtPrecio.setText(Double.toString(product.getPrecio()));
            txtFecha.setText(DateUtil.format(product.getFecha()));
        } else {
            // Person is null, remove all the text.
        	txtDescripcion.setText("");
        	txtStock.setText("");
        	txtPrecio.setText("");
            txtFecha.setText("");
        }
    }
    
    //Comunicacion con Main.java
    public void setMainApp(Main main) {
        this.main = main;
        // Add observable list data to the table
        productTable.setItems(this.main.getProductData());
    }
    
}

