package application;

import java.time.LocalDate;

import javafx.beans.property.DoubleProperty;
import javafx.beans.property.IntegerProperty;
import javafx.beans.property.ObjectProperty;
import javafx.beans.property.SimpleDoubleProperty;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleObjectProperty;
import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public class Product {

	private final StringProperty descripcion;
    private final IntegerProperty stock;
    private final DoubleProperty precio;
    private final ObjectProperty<LocalDate> fecha;
    
    public Product() {
		this(null,0,0,null);
	}

	public Product(String descripcion, int stock, double precio, LocalDate  fecha) {
        this.descripcion = new SimpleStringProperty(descripcion);
        this.stock = new SimpleIntegerProperty(stock);
        this.precio = new SimpleDoubleProperty(precio);
        this.fecha = new SimpleObjectProperty<LocalDate>(fecha);
    }
    
    public String getDescripcion() {
        return descripcion.get();
    }

    public void setDescripcion(String descripcion) {
        this.descripcion.set(descripcion);
    }
    
    public StringProperty descripcionProperty() {
        return descripcion;
    }

    public int getStock() {
        return stock.get();
    }

    public void setStock(int stock) {
        this.stock.set(stock);
    }
    
    public IntegerProperty stockProperty() {
        return stock;
    }
    
    public double getPrecio() {
        return precio.get();
    }

    public void setPrecio(double precio) {
        this.precio.set(precio);
    }
    
    public DoubleProperty precioProperty() {
        return precio;
    }
    
    public LocalDate getFecha() {
        return fecha.get();
    }

    public void setFecha(LocalDate fecha) {
        this.fecha.set(fecha);
    }
    
    public ObjectProperty<LocalDate> fechaProperty() {
        return fecha;
    }
    
}
