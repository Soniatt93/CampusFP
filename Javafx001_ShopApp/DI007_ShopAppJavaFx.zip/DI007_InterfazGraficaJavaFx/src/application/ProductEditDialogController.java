package application;

import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ProductEditDialogController {

    @FXML
    private TextField descripcionTxt;
    @FXML
    private TextField stockTxt;
    @FXML
    private TextField precioTxt;
    @FXML
    private TextField fechaTxt;

    private Stage dialogStage;
    private Product product;
    private boolean okClicked = false;

    @FXML
    private void initialize() {
    }

    public void setDialogStage(Stage dialogStage) {
        this.dialogStage = dialogStage;
    }

    public void setProduct(Product product){
        this.product = product;

        descripcionTxt.setText(product.getDescripcion());
        stockTxt.setText(Integer.toString(product.getStock()));
        precioTxt.setText(Double.toString(product.getPrecio()));
        fechaTxt.setText(DateUtil.format(product.getFecha()));
        fechaTxt.setPromptText("dd.mm.yyyy");
    }

    public boolean isOkClicked(){
        return okClicked;
    }

    @FXML
    private void handleOk(){
        if (isInputValid()){
        	product.setDescripcion(descripcionTxt.getText());
        	product.setStock(Integer.parseInt(stockTxt.getText()));
        	product.setPrecio(Double.parseDouble(precioTxt.getText()));
        	product.setFecha(DateUtil.parse(fechaTxt.getText()));
            okClicked = true;
            dialogStage.close();
        }
    }

    @FXML
    private void handleCancel() {
        dialogStage.close();
    }

    private boolean isInputValid() {
        String errorMessage = "";

        if (descripcionTxt.getText() == null || descripcionTxt.getText().length() == 0) {
            errorMessage += "Descripcion invalida!\n"; 
        }

        if (stockTxt.getText() == null || stockTxt.getText().length() == 0) {
            errorMessage += "Unidades stock invalidas\n"; 
        } else {
            try {
                Integer.parseInt(stockTxt.getText());
            } catch (NumberFormatException e) {
                errorMessage += "Unidades stock invalidas. (Tiene que introducir un numero)\n"; 
            }
        }
        
        if (precioTxt.getText() == null || precioTxt.getText().length() == 0) {
            errorMessage += "Precio invalido\n"; 
        } else {
            try {
                Double.parseDouble(precioTxt.getText());
            } catch (NumberFormatException e) {
                errorMessage += "Precio invalido. (Tiene que introducir un numero)\n"; 
            }
        }

        if (fechaTxt.getText() == null || fechaTxt.getText().length() == 0) {
            errorMessage += "Fecha invalida\n";
        } else {
            if (!DateUtil.validDate(fechaTxt.getText())) {
                errorMessage += "Fecha invalida. Usa el formato dd.mm.yyyy!\n";
            }
        }

        if (errorMessage.length() == 0) {
            return true;
        } else {
        	Alert alert = new Alert(AlertType.INFORMATION);
        	alert.setTitle("Informaci�n");
        	alert.setHeaderText(null);
        	alert.setContentText(errorMessage);
        	alert.showAndWait();
            return false;
        }
    }
}