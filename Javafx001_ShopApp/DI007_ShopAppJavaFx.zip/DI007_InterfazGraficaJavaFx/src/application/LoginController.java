package application;

import java.io.IOException;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.Image;
import javafx.stage.Stage;

public class LoginController {

	private Main main;
	private BorderPane rootLayout;
	
    @FXML
    private Button btnLogin;

    @FXML
    private TextField txtEmail;

    @FXML
    private PasswordField txtPassword;

    @FXML
    void login(ActionEvent event) {
    	//Creamos la alerta que aparecer� para decirnos si hemos introducido bien las credenciales
    	Alert alert = new Alert(AlertType.INFORMATION);
    	alert.setTitle("Informaci�n");
    	alert.setHeaderText(null);
    	
    	//Variables ficticias para emular un inicio de sesi�n
    	String email = "sonia@gmail.com";
    	String password = "123";
    	
    	//Comprobamos si coinciden los datos del login
    	if(txtEmail.getText().equals(email) && txtPassword.getText().equals(password)) {
    		//Si coincide, nos muestra el siguiente mensaje
    		alert.setContentText("Ha iniciado sesi�n correctamente");

            Stage stage = new Stage();
			try {
				FXMLLoader loader = new FXMLLoader();
	            loader.setLocation(Main.class.getResource("RootLayout.fxml"));
	            rootLayout = (BorderPane) loader.load();			
	        } catch (IOException e) {
				e.printStackTrace();
			}
            Scene escena = new Scene(rootLayout);
            stage.setTitle("MENU USUARIO");
            stage.getIcons().add(new Image("file:resources/images/log.png"));
            stage.setScene(escena);
            stage.show();
            
            showProductOverview();
            
            //en esta linea, esconde el Stage del Login y carga el nuevo stage
            ( (Node) (event.getSource() ) ).getScene().getWindow().hide();
    		
    	}else {
    		//Si no hemos escrito bien nuestra credenciales, nos muestra este otro
    		alert.setContentText("Email y/o contrase�a incorrectos");
    		System.out.println(email +" "+password+" "+txtEmail.getText()+" "+txtPassword.getText()+" ");
    	}
    	
    	alert.showAndWait();
    }
    
    public void showProductOverview() {
        try {
            // Load person overview.
            FXMLLoader loader = new FXMLLoader();
            loader.setLocation(Main.class.getResource("Product.fxml"));
            AnchorPane productOverview = (AnchorPane) loader.load();
            
            // Set person overview into the center of root layout.
            rootLayout.setCenter(productOverview);
            
            ProductController controller = loader.getController();
            controller.setMainApp(main);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
    
    
    public void setMainApp(Main main) {
        this.main = main;
    }

}
