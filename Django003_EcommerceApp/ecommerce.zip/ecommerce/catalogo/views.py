from django.shortcuts import render
from .models import Product, Tipo
from .forms import ProductCreate

def home(request):
    catalogo = Product.objects.all()
    context = {
        'catalogo': catalogo
    }
    return render(request, 'home.html', context)

def catalogo_mac(request):
    macs = Product.objects.filter(tipo__name="mac")
    context = {
        'macs': macs
    }
    return render(request, 'catalogo_mac.html', context)

def mac_detail(request, pk):
    mac= Product.objects.get(pk=pk)
    context = {
        'mac': mac
    }
    return render(request, 'mac_detail.html', context)

def catalogo_iphone(request):
    iphones = Product.objects.filter(tipo__name="iPhone")
    context = {
        'iphones': iphones
    }
    return render(request, 'catalogo_iphone.html', context)

def iphone_detail(request, pk):
    iphone= Product.objects.get(pk=pk)
    context = {
        'iphone': iphone
    }
    return render(request, 'iphone_detail.html', context)

def catalogo_ipad(request):
    ipads = Product.objects.filter(tipo__name="iPad")
    context = {
        'ipads': ipads
    }
    return render(request, 'catalogo_ipad.html', context)

def ipad_detail(request, pk):
    ipad= Product.objects.get(pk=pk)
    context = {
        'ipad': ipad
    }
    return render(request, 'ipad_detail.html', context)

def contact(request):
    return render(request, 'contact.html')

def acabado_iphone(request, name, color):
    iphone= Product.objects.get(name=name, color=color)
    return iphone_detail(request,iphone.pk)

def acabado_ipad(request, name, color):
    ipad= Product.objects.get(name=name, color=color)
    return ipad_detail(request,ipad.pk)

def acabado_mac(request, name, color):
    mac= Product.objects.get(name=name, color=color)
    return mac_detail(request,mac.pk)