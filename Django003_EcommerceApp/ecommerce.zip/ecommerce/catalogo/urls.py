from django.urls import path
from . import views
from ecommerce.settings import DEBUG, STATIC_URL, STATIC_ROOT, MEDIA_URL, MEDIA_ROOT
from django.conf.urls.static import static

urlpatterns = [
    path("", views.home, name="home"),
    path("mac", views.catalogo_mac, name="catalogo_mac"),
    path("mac<int:pk>", views.mac_detail, name="mac_detail"),
    path("iPhone", views.catalogo_iphone, name="catalogo_iphone"),
    path("iPhone/<int:pk>", views.iphone_detail, name="iphone_detail"),
    path("iPad", views.catalogo_ipad, name="catalogo_ipad"),
    path("iPad<int:pk>", views.ipad_detail, name="ipad_detail"),
    path("contacto", views.contact, name="contact"),
    path("iPhone/<str:name>/<str:color>", views.acabado_iphone, name="acabado_iphone"),
    path("iPad/<str:name>/<str:color>", views.acabado_ipad, name="acabado_ipad"),
    path("mac/<str:name>/<str:color>", views.acabado_mac, name="acabado_mac"),
]

#DataFlair
if DEBUG:
    urlpatterns += static(STATIC_URL, document_root = STATIC_ROOT)
    urlpatterns += static(MEDIA_URL, document_root = MEDIA_ROOT)