from django.apps import AppConfig


class CatalogoConfig(AppConfig):
    name = 'catalogo'
