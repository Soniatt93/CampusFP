from django.db import models

class Tipo(models.Model):
    name = models.CharField(max_length=50, help_text="Ingrese el tipo de producto (p. ej. iPhone, iPad etc.)")
    
    def __str__(self):
        return self.name

class Product(models.Model):
    name= models.CharField(max_length=100)
    description = models.TextField()
    color = models.CharField(max_length=25)
    capacity = models.CharField(max_length=5)
    price= models.CharField(max_length=10)
    image = models.ImageField()
    tipo = models.ManyToManyField(Tipo, help_text="Seleccione el tipo de producto")

    class Meta: 
        ordering = ["-name"]

    def __str__(self):
       return self.name

    def display_tipo(self):
        return ', '.join([ tipo.name for tipo in self.tipo.all()[:3] ])
    display_tipo.short_description = 'Tipo'