package application;

import javafx.fxml.FXML;
import javafx.scene.control.Label;

public class SampleController {
	@FXML
	private Label label1;
	@FXML
	public void mostrar() {
		System.out.println("Hola mundo");
		//Label label1 = new Label();
		label1.setText("Bienvenido");
	}
}
